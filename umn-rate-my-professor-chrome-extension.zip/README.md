# UMN Rate My Professor Chrome Extension

Rate my professor chrome extension for University of Minnesota Twin Cities.

Loads ratings and reviews for professors right on the schedule builder:
No more flipping back and forth and searching manually!

- Now on the Chrome Web Store
  https://chrome.google.com/webstore/detail/rate-my-gopher-umn-profes/pmblceckdalgamfhocahemcelikplpkg

To install:

- Go to chrome://extensions
- Now, Enable developer mode
- Click on Load Unpacked and the unzipped, file folder.
- The extension will now be installed

OR:

- Download from the Chrome Web Store: https://chrome.google.com/webstore/detail/rate-my-gopher-umn-profes/pmblceckdalgamfhocahemcelikplpkg

Note: You must use the folder in which the manifest.json exists.
